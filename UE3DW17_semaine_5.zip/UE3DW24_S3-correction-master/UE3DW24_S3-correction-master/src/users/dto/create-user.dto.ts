export class CreateUserDto {
    id: number;
    firstname: string;
    lastname: string;
    createdAt: Date;
    updatedAt: Date;
}
